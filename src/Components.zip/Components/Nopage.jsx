import React from 'react'

export default function Nopage() {
  return (
    <div>Nopage</div>
  )
}
