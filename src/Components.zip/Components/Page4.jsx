import React from 'react'

export default function Page4() {
  return (
    <div>Page4</div>
  )
}
